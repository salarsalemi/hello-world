#!/bin/bash

pip install pipenv
pipenv install --dev --skip-lock
